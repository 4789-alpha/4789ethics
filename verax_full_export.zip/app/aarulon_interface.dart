class AarulonInterface {
  void connect() {
    print('Verbindung zu Aarulon initialisiert...');
  }
}
