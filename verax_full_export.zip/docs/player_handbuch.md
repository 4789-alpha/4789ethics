# VERAX Spieler-Handbuch

## Eingabe über Lautstärketasten
Laut kurz: zurückweichen  
Laut lang: erlösen  
Leise kurz: beobachten  
Leise lang: ausnehmen  
