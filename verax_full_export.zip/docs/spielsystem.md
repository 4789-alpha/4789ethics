# VERAX Spielsystem (ehemals Codex)
Struktur zur Steuerung der Entscheidung, Bewegung, Umwelt und Auswertung.
Siehe verhalten.yaml für Beispiele.
