# VERAX
Dies ist ein vollständiges Demo-Paket für die strukturierte Bewegungssimulation im BSVRB-Kontext.